<?php if($config['template_allow_change']): ?>
<div class="sidebar">
	<h2>Change style</h2>
	<?php echo template_form(); ?>
</div>
<?php endif; ?>