<div class="sidebar">
	<h2><?php echo generateLink(ADMIN_URL, 'Admin Panel', true); ?></h2>
</div>