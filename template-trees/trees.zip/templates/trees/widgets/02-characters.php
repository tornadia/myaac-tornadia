<div class="sidebar">
	<h2>Character search</h2>
	<div class="inner">
		<form type="submit" action="<?php echo getLink('characters'); ?>" method="post">
			<input type="text" name="name" class="search">
			<input type="submit" value="Search" />
		</form>
	</div>
</div>