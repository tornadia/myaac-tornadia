<?php
$config['darkborder'] = "#DDD";
$config['lightborder'] = "#fcfcfc";
$config['vdarkborder'] = "#555";
$config['news_title_color'] = "white";
$config['menu_categories'] = array(
	1 => array('name' => 'Home'),
	2 => array('name' => 'Account'),
	3 => array('name' => 'Community'),
	4 => array('name' => 'Library'),
	5 => array('name' => 'Forum'),
	6 => array('name' => 'Help'),
	7 => array('name' => 'Shop'),
	8 => array('name' => 'Account Menu')
);

?>
