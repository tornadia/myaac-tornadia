<?php

function get_inner_html( $node ) {
	$innerHTML= '';
	$children = $node->childNodes;
	foreach ($children as $child) {
		$innerHTML .= $child->ownerDocument->saveXML( $child );
	}
	
	return $innerHTML;  }

echo 'Downloading creatures.html...';
$content = file_get_contents('http://www.tibia.com/library/?subtopic=creatures');
file_put_contents('creatures.html', $content);
echo 'DONE' . PHP_EOL;

$dom = new DOMDocument();
@$dom->loadHTMLFile('creatures.html');

$creatures_downloaded = 0;
$images_downloaded = 0;
$divs = $dom->getElementsByTagName('div');
foreach ($divs as $div) {
	if($div->getAttribute('class') == 'BoxContent')
	{
		$content = get_inner_html($div);
		$dom = new DOMDocument();
		$dom->loadHTML($content);
		
		// link to creature
		$content = preg_replace('/(http:\/\/www.tibia.com\/library\/\?subtopic=creatures&amp;race=(.*?))/si', '?subtopic=creatures&race=$2', $content);
		
		// image of creature
		$content = preg_replace('/(http:\/\/static.tibia.com\/images\/library\/(.*?))/si', 'images/creatures/$2', $content);
		
		file_put_contents('system/templates/creatures/creatures.html.twig', $content);
		$hrefs = $dom->getElementsByTagName('a');
		foreach ($hrefs as $href) {
			$href_url = $href->getAttribute('href');
			$tmp = explode('race=', $href_url);
			$filename = $tmp[1];
			if(!file_exists('system/templates/creatures/' . $filename . '.html.twig')) {
				echo 'downloading ' . $filename . '.html.twig' . PHP_EOL;
				
				$creature = file_get_contents($href_url);
				
				$dom2 = new DOMDocument();
				@$dom2->loadHTML($creature);
				
				$divs2 = $dom2->getElementsByTagName('div');
				foreach ($divs2 as $div2) {
					if ($div2->getAttribute('class') == 'BoxContent') {
						$innerHTML = get_inner_html($div2);
						
						// replace arrows
						$innerHTML = str_replace('http://static.tibia.com/images/gameguides/arrow_right.gif', 'images/arrow_right.gif', $innerHTML);
						$innerHTML = str_replace('http://static.tibia.com/images/gameguides/arrow_left.gif', 'images/arrow_left.gif', $innerHTML);
						$innerHTML = str_replace('http://static.tibia.com/images/gameguides/arrow_up.gif', 'images/arrow_up.gif', $innerHTML);
						
						// link to next/previous creature
						$innerHTML = preg_replace('/(http:\/\/www.tibia.com\/library\/\?subtopic=creatures&amp;race=(.*?))/si', '?subtopic=creatures&race=$2', $innerHTML);
						
						// link to creatures
						$innerHTML = str_replace('http://www.tibia.com/library/?subtopic=creatures', '?subtopic=creatures', $innerHTML);
						
						// image of creature
						$innerHTML = preg_replace('/(http:\/\/static.tibia.com\/images\/library\/(.*?))/si', 'images/creatures/$2', $innerHTML);
						file_put_contents('system/templates/creatures/' . $filename . '.html.twig', trim($innerHTML));
					}
				}
				
				sleep(3);
				$creatures_downloaded++;
			}
		}
		
		$imgs = $dom->getElementsByTagName('img');
		foreach ($imgs as $img) {
			$src = $img->getAttribute('src');
			$filename = pathinfo($src, PATHINFO_FILENAME);
		
			if(!file_exists('images/creatures/' . $filename . '.gif')) {
				echo 'downloading ' . $filename . '.gif' . PHP_EOL;
				
				$gif = file_get_contents($src);
				file_put_contents('images/creatures/' . $filename . '.gif', $gif);
				sleep(1);
				$images_downloaded++;
			}
		}
	}
}

echo 'Total creatures downloaded: ' . $creatures_downloaded . PHP_EOL;
echo 'Total images downloaded: ' . $images_downloaded;